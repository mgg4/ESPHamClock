// N.B. if beta be sure to use 2 places: 4.09b01

const char *hc_version = "4.22";
